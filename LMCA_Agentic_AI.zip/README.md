# LMCA - Agentic AI Project

This is a Livestock Market Chain Analyzer using LangChain Agentic AI workflows and Firebase.

## Features
- Analyze livestock prices using AI agents
- Detect bottlenecks in the value chain
- Firebase integration for real data
- Modular LangChain agent setup

## Setup
1. Add your `firebase-key.json` file to the root directory.
2. Create a `.env` file with your OpenAI key.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Run the project:

```bash
python main.py
```
