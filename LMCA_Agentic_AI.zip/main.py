from langchain.agents import initialize_agent, Tool
from langchain.chat_models import ChatOpenAI
import os

# Example placeholder functions
def analyze_prices(query):
    return "Goat prices have increased by 10% in the last 6 months in Gursum."

def detect_bottlenecks(query):
    return "Transportation is the key bottleneck in the livestock chain in Gursum."

llm = ChatOpenAI(model="gpt-4", temperature=0)
tools = [
    Tool(name="LivestockPriceAnalyzer", func=analyze_prices, description="Analyzes livestock prices"),
    Tool(name="MarketBottleneckTool", func=detect_bottlenecks, description="Identifies constraints in value chain")
]

agent = initialize_agent(tools, llm, agent="zero-shot-react-description", verbose=True)

query = "What is the goat market trend in Gursum over the past 6 months?"
response = agent.run(query)
print(response)
