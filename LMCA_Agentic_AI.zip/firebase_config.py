import firebase_admin
from firebase_admin import credentials, firestore

cred = credentials.Certificate("firebase-key.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

def fetch_livestock_data():
    docs = db.collection("market_data").where("location", "==", "Gursum").stream()
    return [doc.to_dict() for doc in docs]
